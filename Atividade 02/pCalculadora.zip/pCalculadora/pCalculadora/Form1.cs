﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pCalculadora
{
    public partial class Form1 : Form
    {
        double numero01, numero02, resultado;
        public Form1()
        {
            InitializeComponent();
           
        }

        private void MskNumero02_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskNumero02.Text , out numero02))
            {
                MessageBox.Show("Número Inválido");
            }
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnMais_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(mskNumero01.Text , out numero01))
            {
                MessageBox.Show("Número Inválido");

            }
            

            if (!double.TryParse(mskNumero02.Text, out numero02))
            {
               
                MessageBox.Show("Número Inválido");

            }
            




            resultado = numero01 + numero02;
            mskResultado.Text = resultado.ToString();
        }

        private void BtnMenos_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(mskNumero01.Text , out numero01))
            {
                MessageBox.Show("Número Inválido");
            }
            if (!double.TryParse(mskNumero02.Text, out numero02))
            {
                MessageBox.Show("Número Inválido");
            }

            resultado = numero01 - numero02;
            mskResultado.Text = resultado.ToString();
        }

        private void BtnMultiplicar_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(mskNumero01.Text , out numero01))
            {
                MessageBox.Show("Número Inválido");
            }
            if(!double.TryParse(mskNumero02.Text , out numero02))
            {
                MessageBox.Show("Número Inválido");
            }

            resultado = numero01 * numero02;
            mskResultado.Text = resultado.ToString();
        }

        private void BtnDividir_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(mskNumero01.Text, out numero01))
            {
                MessageBox.Show("Número Inválido");
            }
            if (numero01 == 0)
            {
                MessageBox.Show("Não pode ser dividido por zero");
            }

            if (!double.TryParse(mskNumero02.Text, out numero02))
            {
                MessageBox.Show("Número Inválido");
            }
            if (numero02 == 0)
            {
                MessageBox.Show("Não pode ser dividido por zero");
            }
             resultado = numero01 / numero02;
            mskResultado.Text = resultado.ToString();


        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            mskNumero01.Clear();
            mskNumero02.Clear();
            mskResultado.Clear();
        }

        private void MskNumero01_Validated(object sender, EventArgs e)
        {
           if (!double.TryParse(mskNumero01.Text , out numero01))
            {
                MessageBox.Show("Número Inválido");
            }

        }
        
    }
}
