﻿namespace pCalculadora
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbln01 = new System.Windows.Forms.Label();
            this.lbln02 = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnMais = new System.Windows.Forms.Button();
            this.btnMenos = new System.Windows.Forms.Button();
            this.btnMultiplicar = new System.Windows.Forms.Button();
            this.btnDividir = new System.Windows.Forms.Button();
            this.mskNumero01 = new System.Windows.Forms.MaskedTextBox();
            this.mskNumero02 = new System.Windows.Forms.MaskedTextBox();
            this.mskResultado = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // lbln01
            // 
            this.lbln01.AutoSize = true;
            this.lbln01.Location = new System.Drawing.Point(123, 63);
            this.lbln01.Name = "lbln01";
            this.lbln01.Size = new System.Drawing.Size(59, 13);
            this.lbln01.TabIndex = 0;
            this.lbln01.Text = "Numero 01";
            // 
            // lbln02
            // 
            this.lbln02.AutoSize = true;
            this.lbln02.Location = new System.Drawing.Point(122, 117);
            this.lbln02.Name = "lbln02";
            this.lbln02.Size = new System.Drawing.Size(59, 13);
            this.lbln02.TabIndex = 4;
            this.lbln02.Text = "Numero 02";
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(122, 175);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(55, 13);
            this.lblResultado.TabIndex = 5;
            this.lblResultado.Text = "Resultado";
            // 
            // btnLimpar
            // 
            this.btnLimpar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLimpar.Location = new System.Drawing.Point(568, 56);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(271, 57);
            this.btnLimpar.TabIndex = 6;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSair.Location = new System.Drawing.Point(568, 131);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(271, 57);
            this.btnSair.TabIndex = 7;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // btnMais
            // 
            this.btnMais.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMais.Location = new System.Drawing.Point(29, 242);
            this.btnMais.Name = "btnMais";
            this.btnMais.Size = new System.Drawing.Size(271, 57);
            this.btnMais.TabIndex = 8;
            this.btnMais.Text = "+";
            this.btnMais.UseVisualStyleBackColor = true;
            this.btnMais.Click += new System.EventHandler(this.BtnMais_Click);
            // 
            // btnMenos
            // 
            this.btnMenos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMenos.Location = new System.Drawing.Point(29, 348);
            this.btnMenos.Name = "btnMenos";
            this.btnMenos.Size = new System.Drawing.Size(271, 57);
            this.btnMenos.TabIndex = 9;
            this.btnMenos.Text = "-";
            this.btnMenos.UseVisualStyleBackColor = true;
            this.btnMenos.Click += new System.EventHandler(this.BtnMenos_Click);
            // 
            // btnMultiplicar
            // 
            this.btnMultiplicar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMultiplicar.Location = new System.Drawing.Point(414, 242);
            this.btnMultiplicar.Name = "btnMultiplicar";
            this.btnMultiplicar.Size = new System.Drawing.Size(271, 57);
            this.btnMultiplicar.TabIndex = 10;
            this.btnMultiplicar.Text = "*";
            this.btnMultiplicar.UseVisualStyleBackColor = true;
            this.btnMultiplicar.Click += new System.EventHandler(this.BtnMultiplicar_Click);
            // 
            // btnDividir
            // 
            this.btnDividir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDividir.Location = new System.Drawing.Point(414, 358);
            this.btnDividir.Name = "btnDividir";
            this.btnDividir.Size = new System.Drawing.Size(271, 57);
            this.btnDividir.TabIndex = 11;
            this.btnDividir.Text = "/";
            this.btnDividir.UseVisualStyleBackColor = true;
            this.btnDividir.Click += new System.EventHandler(this.BtnDividir_Click);
            // 
            // mskNumero01
            // 
            this.mskNumero01.Location = new System.Drawing.Point(250, 56);
            this.mskNumero01.Name = "mskNumero01";
            this.mskNumero01.Size = new System.Drawing.Size(259, 20);
            this.mskNumero01.TabIndex = 12;
            this.mskNumero01.Validated += new System.EventHandler(this.MskNumero01_Validated);
            // 
            // mskNumero02
            // 
            this.mskNumero02.Location = new System.Drawing.Point(250, 117);
            this.mskNumero02.Name = "mskNumero02";
            this.mskNumero02.Size = new System.Drawing.Size(259, 20);
            this.mskNumero02.TabIndex = 13;
            this.mskNumero02.Validated += new System.EventHandler(this.MskNumero02_Validated);
            // 
            // mskResultado
            // 
            this.mskResultado.Location = new System.Drawing.Point(250, 175);
            this.mskResultado.Name = "mskResultado";
            this.mskResultado.ReadOnly = true;
            this.mskResultado.Size = new System.Drawing.Size(259, 20);
            this.mskResultado.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.CausesValidation = false;
            this.ClientSize = new System.Drawing.Size(1139, 606);
            this.Controls.Add(this.mskResultado);
            this.Controls.Add(this.mskNumero02);
            this.Controls.Add(this.mskNumero01);
            this.Controls.Add(this.btnDividir);
            this.Controls.Add(this.btnMultiplicar);
            this.Controls.Add(this.btnMenos);
            this.Controls.Add(this.btnMais);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.lbln02);
            this.Controls.Add(this.lbln01);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbln01;
        private System.Windows.Forms.Label lbln02;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnMais;
        private System.Windows.Forms.Button btnMenos;
        private System.Windows.Forms.Button btnMultiplicar;
        private System.Windows.Forms.Button btnDividir;
        private System.Windows.Forms.MaskedTextBox mskNumero01;
        private System.Windows.Forms.MaskedTextBox mskNumero02;
        private System.Windows.Forms.MaskedTextBox mskResultado;
    }
}

