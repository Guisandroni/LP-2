﻿namespace Pclasses
{
    partial class FrmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInstanciarH = new System.Windows.Forms.Button();
            this.gbxhomeoffice = new System.Windows.Forms.GroupBox();
            this.rbnnao = new System.Windows.Forms.RadioButton();
            this.rbnsim = new System.Windows.Forms.RadioButton();
            this.lbldataentradaempresa = new System.Windows.Forms.Label();
            this.lblsalariohora = new System.Windows.Forms.Label();
            this.lblmatricula = new System.Windows.Forms.Label();
            this.lblnome = new System.Windows.Forms.Label();
            this.txtdataentrada = new System.Windows.Forms.TextBox();
            this.txtsalariohora = new System.Windows.Forms.TextBox();
            this.txtmatricula = new System.Windows.Forms.TextBox();
            this.txtnome = new System.Windows.Forms.TextBox();
            this.lblnhoras = new System.Windows.Forms.Label();
            this.lblFaltas = new System.Windows.Forms.Label();
            this.txtnhoras = new System.Windows.Forms.TextBox();
            this.txtfaltas = new System.Windows.Forms.TextBox();
            this.gbxhomeoffice.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnInstanciarH
            // 
            this.btnInstanciarH.Location = new System.Drawing.Point(185, 351);
            this.btnInstanciarH.Name = "btnInstanciarH";
            this.btnInstanciarH.Size = new System.Drawing.Size(325, 87);
            this.btnInstanciarH.TabIndex = 20;
            this.btnInstanciarH.Text = "Instanciar Horista";
            this.btnInstanciarH.UseVisualStyleBackColor = true;
            this.btnInstanciarH.Click += new System.EventHandler(this.BtnInstanciarH_Click);
            // 
            // gbxhomeoffice
            // 
            this.gbxhomeoffice.Controls.Add(this.rbnnao);
            this.gbxhomeoffice.Controls.Add(this.rbnsim);
            this.gbxhomeoffice.Location = new System.Drawing.Point(573, 28);
            this.gbxhomeoffice.Name = "gbxhomeoffice";
            this.gbxhomeoffice.Size = new System.Drawing.Size(196, 201);
            this.gbxhomeoffice.TabIndex = 19;
            this.gbxhomeoffice.TabStop = false;
            this.gbxhomeoffice.Text = "Trabalha em HomeOffice ?";
            // 
            // rbnnao
            // 
            this.rbnnao.AutoSize = true;
            this.rbnnao.Checked = true;
            this.rbnnao.Location = new System.Drawing.Point(18, 116);
            this.rbnnao.Name = "rbnnao";
            this.rbnnao.Size = new System.Drawing.Size(45, 17);
            this.rbnnao.TabIndex = 10;
            this.rbnnao.TabStop = true;
            this.rbnnao.Text = "Não";
            this.rbnnao.UseVisualStyleBackColor = true;
            // 
            // rbnsim
            // 
            this.rbnsim.AutoSize = true;
            this.rbnsim.Location = new System.Drawing.Point(18, 69);
            this.rbnsim.Name = "rbnsim";
            this.rbnsim.Size = new System.Drawing.Size(42, 17);
            this.rbnsim.TabIndex = 9;
            this.rbnsim.Text = "Sim";
            this.rbnsim.UseVisualStyleBackColor = true;
            // 
            // lbldataentradaempresa
            // 
            this.lbldataentradaempresa.AutoSize = true;
            this.lbldataentradaempresa.Location = new System.Drawing.Point(25, 206);
            this.lbldataentradaempresa.Name = "lbldataentradaempresa";
            this.lbldataentradaempresa.Size = new System.Drawing.Size(129, 13);
            this.lbldataentradaempresa.TabIndex = 18;
            this.lbldataentradaempresa.Text = "Data Entrada na Empresa";
            // 
            // lblsalariohora
            // 
            this.lblsalariohora.AutoSize = true;
            this.lblsalariohora.Location = new System.Drawing.Point(25, 151);
            this.lblsalariohora.Name = "lblsalariohora";
            this.lblsalariohora.Size = new System.Drawing.Size(73, 13);
            this.lblsalariohora.TabIndex = 17;
            this.lblsalariohora.Text = "Sálario / Hora";
            // 
            // lblmatricula
            // 
            this.lblmatricula.AutoSize = true;
            this.lblmatricula.Location = new System.Drawing.Point(25, 96);
            this.lblmatricula.Name = "lblmatricula";
            this.lblmatricula.Size = new System.Drawing.Size(50, 13);
            this.lblmatricula.TabIndex = 16;
            this.lblmatricula.Text = "Matricula";
            // 
            // lblnome
            // 
            this.lblnome.AutoSize = true;
            this.lblnome.Location = new System.Drawing.Point(25, 41);
            this.lblnome.Name = "lblnome";
            this.lblnome.Size = new System.Drawing.Size(35, 13);
            this.lblnome.TabIndex = 15;
            this.lblnome.Text = "Nome";
            // 
            // txtdataentrada
            // 
            this.txtdataentrada.Location = new System.Drawing.Point(185, 199);
            this.txtdataentrada.Name = "txtdataentrada";
            this.txtdataentrada.Size = new System.Drawing.Size(325, 20);
            this.txtdataentrada.TabIndex = 14;
            // 
            // txtsalariohora
            // 
            this.txtsalariohora.Location = new System.Drawing.Point(185, 144);
            this.txtsalariohora.Name = "txtsalariohora";
            this.txtsalariohora.Size = new System.Drawing.Size(325, 20);
            this.txtsalariohora.TabIndex = 13;
            // 
            // txtmatricula
            // 
            this.txtmatricula.Location = new System.Drawing.Point(185, 89);
            this.txtmatricula.Name = "txtmatricula";
            this.txtmatricula.Size = new System.Drawing.Size(325, 20);
            this.txtmatricula.TabIndex = 12;
            // 
            // txtnome
            // 
            this.txtnome.Location = new System.Drawing.Point(185, 41);
            this.txtnome.Name = "txtnome";
            this.txtnome.Size = new System.Drawing.Size(325, 20);
            this.txtnome.TabIndex = 11;
            // 
            // lblnhoras
            // 
            this.lblnhoras.AutoSize = true;
            this.lblnhoras.Location = new System.Drawing.Point(23, 257);
            this.lblnhoras.Name = "lblnhoras";
            this.lblnhoras.Size = new System.Drawing.Size(90, 13);
            this.lblnhoras.TabIndex = 21;
            this.lblnhoras.Text = "Número de Horas";
            // 
            // lblFaltas
            // 
            this.lblFaltas.AutoSize = true;
            this.lblFaltas.Location = new System.Drawing.Point(25, 311);
            this.lblFaltas.Name = "lblFaltas";
            this.lblFaltas.Size = new System.Drawing.Size(71, 13);
            this.lblFaltas.TabIndex = 22;
            this.lblFaltas.Text = "Dias de faltas";
            // 
            // txtnhoras
            // 
            this.txtnhoras.Location = new System.Drawing.Point(185, 257);
            this.txtnhoras.Name = "txtnhoras";
            this.txtnhoras.Size = new System.Drawing.Size(325, 20);
            this.txtnhoras.TabIndex = 15;
            // 
            // txtfaltas
            // 
            this.txtfaltas.Location = new System.Drawing.Point(185, 304);
            this.txtfaltas.Name = "txtfaltas";
            this.txtfaltas.Size = new System.Drawing.Size(325, 20);
            this.txtfaltas.TabIndex = 16;
            // 
            // FrmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtfaltas);
            this.Controls.Add(this.txtnhoras);
            this.Controls.Add(this.lblFaltas);
            this.Controls.Add(this.lblnhoras);
            this.Controls.Add(this.btnInstanciarH);
            this.Controls.Add(this.gbxhomeoffice);
            this.Controls.Add(this.lbldataentradaempresa);
            this.Controls.Add(this.lblsalariohora);
            this.Controls.Add(this.lblmatricula);
            this.Controls.Add(this.lblnome);
            this.Controls.Add(this.txtdataentrada);
            this.Controls.Add(this.txtsalariohora);
            this.Controls.Add(this.txtmatricula);
            this.Controls.Add(this.txtnome);
            this.Name = "FrmHorista";
            this.Text = "FrmHorista";
            this.gbxhomeoffice.ResumeLayout(false);
            this.gbxhomeoffice.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInstanciarH;
        private System.Windows.Forms.GroupBox gbxhomeoffice;
        private System.Windows.Forms.RadioButton rbnnao;
        private System.Windows.Forms.RadioButton rbnsim;
        private System.Windows.Forms.Label lbldataentradaempresa;
        private System.Windows.Forms.Label lblsalariohora;
        private System.Windows.Forms.Label lblmatricula;
        private System.Windows.Forms.Label lblnome;
        private System.Windows.Forms.TextBox txtdataentrada;
        private System.Windows.Forms.TextBox txtsalariohora;
        private System.Windows.Forms.TextBox txtmatricula;
        private System.Windows.Forms.TextBox txtnome;
        private System.Windows.Forms.Label lblnhoras;
        private System.Windows.Forms.Label lblFaltas;
        private System.Windows.Forms.TextBox txtnhoras;
        private System.Windows.Forms.TextBox txtfaltas;
    }
}