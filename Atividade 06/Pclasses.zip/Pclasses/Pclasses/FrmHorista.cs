﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class FrmHorista : Form
    {
        public FrmHorista()
        {
            InitializeComponent();
        }

        private void BtnInstanciarH_Click(object sender, EventArgs e)
        {
            Horista Horista01 = new Horista();
            Horista01.NomeEmpregado = (txtnome.Text);
            Horista01.Matricula = Convert.ToInt32(txtmatricula.Text);
            Horista01.DiasFalta = Convert.ToInt32(txtfaltas.Text);
            Horista01.SalarioHora = Convert.ToInt32(txtsalariohora.Text);
            Horista01.DataEntradaEmpresa = Convert.ToDateTime(txtdataentrada.Text);
            Horista01.NumeroHora = Convert.ToDouble(txtnhoras.Text);

            if (rbnsim.Checked)
                Horista01.HomeOffice = 's';
            else
                Horista01.HomeOffice = 'n';

            //saida dados

            MessageBox.Show("Nome: " + Horista01.NomeEmpregado + "\n" + "Matricula: " + Horista01.Matricula + "\n" +  "Dias de Faltas: " + Horista01.DiasFalta + "\n" +
                "Salario Hora: " + Horista01.SalarioHora + "\n" + "Data Entrada na Empresa: " + Horista01.DataEntradaEmpresa + "\n" +  "Numero Hora: " + Horista01.NumeroHora +
                "\n" + Horista01.verificar());

        }
    }
}
