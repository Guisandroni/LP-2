﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class FrmMensalista : Form
    {
        public FrmMensalista()
        {
            InitializeComponent();
        }

        private void BtnInstanciarM_Click(object sender, EventArgs e)
        {
            Mensalista mensalista01 = new Mensalista();
            mensalista01.Matricula = Convert.ToInt32(txtmatricula.Text);
            mensalista01.DataEntradaEmpresa = Convert.ToDateTime(txtdataentrada.Text);
            mensalista01.NomeEmpregado = (txtnome.Text);
            mensalista01.SalarioMensal = Convert.ToDouble(txtsalariom.Text);

            if (rbnsim.Checked)
                mensalista01.HomeOffice = 's';
            else
                mensalista01.HomeOffice = 'n';

            //get dados

            MessageBox.Show("Matricula: " + mensalista01.Matricula + "\n" + "Nome: " + mensalista01.NomeEmpregado + "\n" +
                "Data Entrada: " + mensalista01.DataEntradaEmpresa.ToShortDateString() +  "\n" + "Sálario Bruto: " +
                mensalista01.SalarioBruto().ToString("N2") + "\n" + "Tempo Empresa (dias): " + 
                mensalista01.TempoTrabalho() + "\n" + mensalista01.verificar());

        }

        private void BtnInstanciarMpp_Click(object sender, EventArgs e)
        {
            Mensalista mensalista01 = new Mensalista(Convert.ToInt32(txtmatricula.Text),
                txtnome.Text,
                Convert.ToDateTime(txtdataentrada.Text),
                Convert.ToDouble(txtsalariom.Text));

            if (rbnsim.Checked)
                mensalista01.HomeOffice = 's';
            else
                mensalista01.HomeOffice = 'n';


            MessageBox.Show("Matricula: " + mensalista01.Matricula + "\n" + "Nome: " + mensalista01.NomeEmpregado + "\n" +
               "Data Entrada: " + mensalista01.DataEntradaEmpresa.ToShortDateString() + "\n" + "Sálario Bruto: " +
               mensalista01.SalarioBruto().ToString("N2") + "\n" + "Tempo Empresa (dias): " +
               mensalista01.TempoTrabalho() + "\n" + mensalista01.verificar());

        }
    }
}
