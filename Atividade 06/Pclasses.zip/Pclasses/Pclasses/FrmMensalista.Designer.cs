﻿namespace Pclasses
{
    partial class FrmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtnome = new System.Windows.Forms.TextBox();
            this.txtmatricula = new System.Windows.Forms.TextBox();
            this.txtsalariom = new System.Windows.Forms.TextBox();
            this.txtdataentrada = new System.Windows.Forms.TextBox();
            this.lblnome = new System.Windows.Forms.Label();
            this.lblmatricula = new System.Windows.Forms.Label();
            this.lblsalariomensal = new System.Windows.Forms.Label();
            this.lbldataentradaempresa = new System.Windows.Forms.Label();
            this.gbxhomeoffice = new System.Windows.Forms.GroupBox();
            this.rbnnao = new System.Windows.Forms.RadioButton();
            this.rbnsim = new System.Windows.Forms.RadioButton();
            this.btnInstanciarM = new System.Windows.Forms.Button();
            this.btnInstanciarMpp = new System.Windows.Forms.Button();
            this.gbxhomeoffice.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtnome
            // 
            this.txtnome.Location = new System.Drawing.Point(185, 57);
            this.txtnome.Name = "txtnome";
            this.txtnome.Size = new System.Drawing.Size(325, 20);
            this.txtnome.TabIndex = 0;
            // 
            // txtmatricula
            // 
            this.txtmatricula.Location = new System.Drawing.Point(185, 112);
            this.txtmatricula.Name = "txtmatricula";
            this.txtmatricula.Size = new System.Drawing.Size(325, 20);
            this.txtmatricula.TabIndex = 1;
            // 
            // txtsalariom
            // 
            this.txtsalariom.Location = new System.Drawing.Point(185, 163);
            this.txtsalariom.Name = "txtsalariom";
            this.txtsalariom.Size = new System.Drawing.Size(325, 20);
            this.txtsalariom.TabIndex = 2;
            // 
            // txtdataentrada
            // 
            this.txtdataentrada.Location = new System.Drawing.Point(187, 215);
            this.txtdataentrada.Name = "txtdataentrada";
            this.txtdataentrada.Size = new System.Drawing.Size(325, 20);
            this.txtdataentrada.TabIndex = 3;
            // 
            // lblnome
            // 
            this.lblnome.AutoSize = true;
            this.lblnome.Location = new System.Drawing.Point(25, 57);
            this.lblnome.Name = "lblnome";
            this.lblnome.Size = new System.Drawing.Size(35, 13);
            this.lblnome.TabIndex = 4;
            this.lblnome.Text = "Nome";
            // 
            // lblmatricula
            // 
            this.lblmatricula.AutoSize = true;
            this.lblmatricula.Location = new System.Drawing.Point(25, 112);
            this.lblmatricula.Name = "lblmatricula";
            this.lblmatricula.Size = new System.Drawing.Size(50, 13);
            this.lblmatricula.TabIndex = 5;
            this.lblmatricula.Text = "Matricula";
            // 
            // lblsalariomensal
            // 
            this.lblsalariomensal.AutoSize = true;
            this.lblsalariomensal.Location = new System.Drawing.Point(25, 163);
            this.lblsalariomensal.Name = "lblsalariomensal";
            this.lblsalariomensal.Size = new System.Drawing.Size(76, 13);
            this.lblsalariomensal.TabIndex = 6;
            this.lblsalariomensal.Text = "Sálario Mensal";
            // 
            // lbldataentradaempresa
            // 
            this.lbldataentradaempresa.AutoSize = true;
            this.lbldataentradaempresa.Location = new System.Drawing.Point(25, 222);
            this.lbldataentradaempresa.Name = "lbldataentradaempresa";
            this.lbldataentradaempresa.Size = new System.Drawing.Size(129, 13);
            this.lbldataentradaempresa.TabIndex = 7;
            this.lbldataentradaempresa.Text = "Data Entrada na Empresa";
            // 
            // gbxhomeoffice
            // 
            this.gbxhomeoffice.Controls.Add(this.rbnnao);
            this.gbxhomeoffice.Controls.Add(this.rbnsim);
            this.gbxhomeoffice.Location = new System.Drawing.Point(573, 44);
            this.gbxhomeoffice.Name = "gbxhomeoffice";
            this.gbxhomeoffice.Size = new System.Drawing.Size(196, 201);
            this.gbxhomeoffice.TabIndex = 8;
            this.gbxhomeoffice.TabStop = false;
            this.gbxhomeoffice.Text = "Trabalha em HomeOffice ?";
            // 
            // rbnnao
            // 
            this.rbnnao.AutoSize = true;
            this.rbnnao.Checked = true;
            this.rbnnao.Location = new System.Drawing.Point(18, 116);
            this.rbnnao.Name = "rbnnao";
            this.rbnnao.Size = new System.Drawing.Size(45, 17);
            this.rbnnao.TabIndex = 10;
            this.rbnnao.TabStop = true;
            this.rbnnao.Text = "Não";
            this.rbnnao.UseVisualStyleBackColor = true;
            // 
            // rbnsim
            // 
            this.rbnsim.AutoSize = true;
            this.rbnsim.Location = new System.Drawing.Point(18, 69);
            this.rbnsim.Name = "rbnsim";
            this.rbnsim.Size = new System.Drawing.Size(42, 17);
            this.rbnsim.TabIndex = 9;
            this.rbnsim.Text = "Sim";
            this.rbnsim.UseVisualStyleBackColor = true;
            // 
            // btnInstanciarM
            // 
            this.btnInstanciarM.Location = new System.Drawing.Point(12, 351);
            this.btnInstanciarM.Name = "btnInstanciarM";
            this.btnInstanciarM.Size = new System.Drawing.Size(325, 87);
            this.btnInstanciarM.TabIndex = 9;
            this.btnInstanciarM.Text = "Instanciar Mensalista";
            this.btnInstanciarM.UseVisualStyleBackColor = true;
            this.btnInstanciarM.Click += new System.EventHandler(this.BtnInstanciarM_Click);
            // 
            // btnInstanciarMpp
            // 
            this.btnInstanciarMpp.Location = new System.Drawing.Point(463, 351);
            this.btnInstanciarMpp.Name = "btnInstanciarMpp";
            this.btnInstanciarMpp.Size = new System.Drawing.Size(325, 87);
            this.btnInstanciarMpp.TabIndex = 10;
            this.btnInstanciarMpp.Text = "Instanciar Mensalista passando parâmetros";
            this.btnInstanciarMpp.UseVisualStyleBackColor = true;
            this.btnInstanciarMpp.Click += new System.EventHandler(this.BtnInstanciarMpp_Click);
            // 
            // FrmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnInstanciarMpp);
            this.Controls.Add(this.btnInstanciarM);
            this.Controls.Add(this.gbxhomeoffice);
            this.Controls.Add(this.lbldataentradaempresa);
            this.Controls.Add(this.lblsalariomensal);
            this.Controls.Add(this.lblmatricula);
            this.Controls.Add(this.lblnome);
            this.Controls.Add(this.txtdataentrada);
            this.Controls.Add(this.txtsalariom);
            this.Controls.Add(this.txtmatricula);
            this.Controls.Add(this.txtnome);
            this.Name = "FrmMensalista";
            this.Text = "FrmMensalista";
            this.gbxhomeoffice.ResumeLayout(false);
            this.gbxhomeoffice.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtnome;
        private System.Windows.Forms.TextBox txtmatricula;
        private System.Windows.Forms.TextBox txtsalariom;
        private System.Windows.Forms.TextBox txtdataentrada;
        private System.Windows.Forms.Label lblnome;
        private System.Windows.Forms.Label lblmatricula;
        private System.Windows.Forms.Label lblsalariomensal;
        private System.Windows.Forms.Label lbldataentradaempresa;
        private System.Windows.Forms.GroupBox gbxhomeoffice;
        private System.Windows.Forms.RadioButton rbnnao;
        private System.Windows.Forms.RadioButton rbnsim;
        private System.Windows.Forms.Button btnInstanciarM;
        private System.Windows.Forms.Button btnInstanciarMpp;
    }
}