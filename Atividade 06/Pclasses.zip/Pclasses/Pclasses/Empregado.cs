﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    abstract class Empregado
    {   //atributos
        private int matricula;
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;
        private char homeoffice;

        public int Matricula
        {   //propriedades
            get { return matricula; }
            set { matricula = value; }
        }
        public string NomeEmpregado
        {   //propriedades
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }
        }
        public DateTime DataEntradaEmpresa
        {   //propriedades
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }

        }
        public char HomeOffice
        {   //propriedades
            get { return homeoffice; }
            set { homeoffice = value; }
        }
        public string verificar()
        {
            if (homeoffice == 's')
                return "trabalha em casa ";
            else
                return "nao trabalha em casa";
        }

        public virtual int TempoTrabalho()
        {
            TimeSpan span = DateTime.Today.Subtract(dataEntradaEmpresa);
            return (span.Days);
        }
        public abstract double SalarioBruto();





    }
   
}
